package Labs_solutions.lab5.prob3;

public interface Shape {
    double computeArea();
}
