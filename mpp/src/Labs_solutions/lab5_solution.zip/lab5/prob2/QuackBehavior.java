package Labs_solutions.lab5.prob2;

public interface QuackBehavior {
    void quack();
}
