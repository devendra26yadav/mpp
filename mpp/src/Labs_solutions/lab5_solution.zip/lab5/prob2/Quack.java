package Labs_solutions.lab5.prob2;

public class Quack implements QuackBehavior{
    @Override
    public void quack() {
        System.out.println("  quacking");
    }
}
