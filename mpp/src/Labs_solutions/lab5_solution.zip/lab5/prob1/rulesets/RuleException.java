package Labs_solutions.lab5.prob1.rulesets;

final public class RuleException extends  Exception{
    public RuleException() {
        super();
    }
    public RuleException(String msg) {
        super(msg);
    }
}
